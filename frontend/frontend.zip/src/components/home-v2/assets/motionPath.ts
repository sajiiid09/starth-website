export const motionPathViewBox = "0 0 1200 900";

export const motionPathD =
  "M160 80 C 520 120 520 420 200 480 C -60 530 120 800 460 820 C 860 850 980 600 760 520 C 540 450 620 220 1040 260";
