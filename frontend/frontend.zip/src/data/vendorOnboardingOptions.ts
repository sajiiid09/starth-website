export const serviceCategoryOptions = [
  "Catering",
  "DJ/Music",
  "Bartending",
  "Security",
  "Photography",
  "Decor",
  "AV/Lighting"
];

export const serviceAreaOptions = ["Local", "Citywide", "Regional", "Nationwide"];
