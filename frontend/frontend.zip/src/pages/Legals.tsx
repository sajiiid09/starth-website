import React from "react";
import Legal from "./Legal";

const Legals: React.FC = () => {
  return <Legal />;
};

export default Legals;
