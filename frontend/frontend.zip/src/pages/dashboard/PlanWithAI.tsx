import React from "react";
import OrganizerAIWorkspace from "@/pages/dashboard/OrganizerAIWorkspace";

const PlanWithAI: React.FC = () => {
  return <OrganizerAIWorkspace />;
};

export default PlanWithAI;
