export const newsItems = [
  {
    title: "Strathwell brings blueprint-level planning to live events",
    source: "Event Journal",
    href: "#"
  },
  {
    title: "How venues are standardizing operations with Strathwell",
    source: "Venue Weekly",
    href: "#"
  },
  {
    title: "The calm stack behind predictable event launches",
    source: "Operations Digest",
    href: "#"
  },
  {
    title: "Blueprint OS streamlines multi-team coordination",
    source: "Planning Today",
    href: "#"
  },
  {
    title: "Strathwell sets a new bar for event readiness",
    source: "Experience Lab",
    href: "#"
  }
];
