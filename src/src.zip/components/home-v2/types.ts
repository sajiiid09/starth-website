export type SectionTheme = "light" | "cream" | "blue";
