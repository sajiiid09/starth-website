export const motionTokens = {
  revealDistance: 40,
  revealDuration: 1,
  revealEase: "power3.out",
  revealBlur: 8,
  revealStart: "top 85%"
};
